package com.algaworks.osworks.domain.repository;

import org.springframework.stereotype.Repository;

@Repository
public class ComentarioRepository {

	//Video in 1h25min - Pause to Launch
}
