package com.algaworks.osworks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OsworksApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(OsworksApiApplication.class, args);
	}

}
