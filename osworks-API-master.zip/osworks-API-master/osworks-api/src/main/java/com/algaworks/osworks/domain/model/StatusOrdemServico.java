package com.algaworks.osworks.domain.model;

public enum StatusOrdemServico {
	
	ABERTA, 
	FINALIZADA, 
	CANCELADA
	
}
